import{l as o,a as r}from"../chunks/BXS4ok-I.js";export{o as load_css,r as start};
