import{l as o,a as r}from"../chunks/DAAR3e-c.js";export{o as load_css,r as start};
